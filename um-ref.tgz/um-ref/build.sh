#!/usr/bin/env bash
# Refresh generated reference files for the um-ref skill.
#
# Run this manually after the upstream API sources change
# ($LBM_REPO/src/java/com/latencybusters/lbm/, $LBM_REPO/src/dotnet/lbmcs/).
# The output .md files are checked in so a fresh clone of this skill
# is immediately usable without running the build first.
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$here"

# LBM_REPO must point at the UM source tree; fail early with a clear
# message instead of failing later inside one of the generators.
if [[ -z "${LBM_REPO:-}" ]]; then
    echo "error: LBM_REPO environment variable is not set" >&2
    exit 1
fi

python3 gen_java_api.py
python3 gen_dotnet_api.py
